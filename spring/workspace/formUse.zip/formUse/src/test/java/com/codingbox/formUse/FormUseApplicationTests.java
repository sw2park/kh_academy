package com.codingbox.formUse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormUseApplicationTests {

	@Test
	void contextLoads() {
	}

}
